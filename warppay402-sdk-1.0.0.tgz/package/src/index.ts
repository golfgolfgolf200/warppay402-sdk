import { privateKeyToAccount } from "viem/accounts";

export interface WarpPayConfig {
  /** Base Mainnet private key of the agent's wallet funding the micro-payments */
  privateKey: `0x${string}`;
  /** Custom gateway URL (Defaults to https://api.warppay402.com) */
  baseUrl?: string;
}

export interface ScrapeResponse {
  success: boolean;
  title: string;
  markdown: string;
  truncated: boolean;
}

export interface BaseAnalyticsResponse {
  success: boolean;
  network: string;
  address: string;
  ethBalance: string;
  nonce: number;
  timestamp: string;
}

export interface PdfExtractorResponse {
  success: boolean;
  pages: number;
  info: Record<string, any>;
  textPreview: string;
}

export class WarpPayClient {
  private baseUrl: string;
  private account;

  constructor(config: WarpPayConfig) {
    this.baseUrl = (config.baseUrl || "https://api.warppay402.com").replace(/\/$/, "");
    this.account = privateKeyToAccount(config.privateKey);
  }

  /**
   * Internal helper handling the initial HTTP request, 402 Payment Required challenge,
   * wallet signing, and automated retry with x402 payment authorization.
   */
  private async executePaidRequest<T>(endpoint: string, payload: Record<string, any>): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;

    // 1. Initial Request
    let response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    // 2. Handle x402 Payment Challenge if 402 status returned
    if (response.status === 402) {
      const authHeader = `x402-address="${this.account.address}"`;

      response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": authHeader,
          "x-402-pay-from": this.account.address,
        },
        body: JSON.stringify(payload),
      });
    }

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`WarpPay API Error (${response.status}): ${errText}`);
    }

    return (await response.json()) as T;
  }

  /**
   * Scrapes any Web URL into clean Markdown for AI context ($0.01 USDC on Base)
   */
  public async scrapeWeb(url: string): Promise<ScrapeResponse> {
    return this.executePaidRequest<ScrapeResponse>("/api/v1/tools/web-scraper", { url });
  }

  /**
   * Fetches Base Mainnet balance and transaction stats for any 0x wallet ($0.02 USDC on Base)
   */
  public async getBaseAnalytics(address: string): Promise<BaseAnalyticsResponse> {
    return this.executePaidRequest<BaseAnalyticsResponse>("/api/v1/tools/base-analytics", { address });
  }

  /**
   * Downloads and extracts text preview from a public PDF URL ($0.05 USDC on Base)
   */
  public async extractPdf(pdfUrl: string): Promise<PdfExtractorResponse> {
    return this.executePaidRequest<PdfExtractorResponse>("/api/v1/tools/pdf-extractor", { pdfUrl });
  }
}
